package midterm.access;

import midterm.AccessA;

public class Main extends AccessA{

	public static void main(String[] args) {
	      
	      Animal myAnimal = new Animal();
	      Animal myAnimalCat = new Cat();
	      Cat myCat = new Cat();
	       
	      Cat cc = (Cat)myAnimalCat;
	      System.out.println(cc.number); // 99
	      System.out.println(myAnimalCat.number); // 10


	      myAnimal.instanceMethod(); // Animal instance method
	      myAnimalCat.instanceMethod(); // Cat instance method // overriding
	      System.out.println(myAnimalCat.number);
	      System.out.println(myAnimalCat.wierdNum);

	      myCat.instanceMethod(); // Cat instance method
	      
	      myAnimal.staticMethod(); // Animal static method
	      myAnimalCat.staticMethod(); // Animal static method // hiding
	      myCat.staticMethod(); // Cat static method
	      myAnimalCat.sayHi();
	      
	   }

}


class Animal{
	int wierdNum = -1;

	int number = 10;
	   public static void staticMethod(){
	      System.out.println("Animal static method");
	   }
	   public void instanceMethod(){
		   System.out.println("inANi:"+number);
	      System.out.println("Animal instance method");
	   }
	   
	   public static void sayHi() {
		   System.out.println("ANIMAL");
	   }
	}

	class Cat extends Animal{
		int number = 99;
	   // @Override 컴파일 에러 
	   public static void staticMethod(){
	      System.out.println("Cat static method");
	   }
	   @Override public void instanceMethod(){
		   System.out.println("inCat: "+number+", this:"+this.number);

	      System.out.println("Cat instance method");
	   }
	   
	   public static void sayHi() {
		   System.out.println("CAT");
	   }

	}