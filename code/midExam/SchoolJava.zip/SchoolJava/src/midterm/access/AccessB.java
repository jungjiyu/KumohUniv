package midterm.access;

import midterm.AccessA;

public class AccessB extends AccessA{ // 디폴트
	
	 public AccessB(){
		 super();

	}

}
