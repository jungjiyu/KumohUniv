package midterm;

import java.util.Arrays;

class MyObject{
    int id;
    String description;

    MyObject(int id, String description) {
        this.id = id;
        this.description = description;
    }
}

public class Main {
	public static void main(String[] args) {
		
		
		Person p00 = new Person(19,"홍길동");
		Person p01 ;
		p01= p00.clone();

		System.out.println(p00);
		System.out.println(p01);

		Person p1 = new Person(19,"홍길동");
		System.out.println("toStirng: "+p1); // toString
		
		Person p2 = new Person(19,"홍길동");
		System.out.println("equals: "+p2.equals(p1));
		System.out.println("equals: "+p1.equals(p1));
		
		
		double aa = 10%0.0;
		System.out.println(Double.isNaN(aa));
		System.out.println("equals: "+p1.equals(aa));

		System.out.println((Double.isNaN(aa))?"NaN입니다":"NaN아닙ㅣ다");
		

		
		char[] c = new char[30];
		char[] c1 = new char[30];
		for(int i = 'a' ; i <= 'z';i++) {
			c[i-'a'] = (char)i;
		}
		for( char ccc:c) {
			System.out.println(ccc);
		}
		
		c1=c.clone();
		System.out.println("c1==c :"+ (c1 == c)+"\r\n");
		
		String s1 = "병신";
		String s2 = "병신";
		System.out.println("s1==s2:"+(s1==s2));
		System.out.println("s1.equals(s2): "+s1.equals(s2)+"\n");
		
		s1 = new String("딸기");
		s2 = new String("딸기");
		System.out.println("s1==s2:"+(s1==s2));
		System.out.println("s1.equals(s2): "+s1.equals(s2)+"\n");
		System.out.println(s1+"의 길이: "+s1.length()+"\n");
		
		String oldStr = "너는 병신이다";
		String newStr = oldStr.replace("너는","나는");
		System.out.println(newStr);
		System.out.println("newStr == oldStr : "+(newStr == oldStr ));
		

		System.out.println("oldStr.indexOf(\"병신\"): "+oldStr.indexOf("병신"));
		System.out.println("oldStr.indexOf(\"바보\"): "+oldStr.indexOf("바보"));
		
		
		String wishList ="바나나, 딸기, 요거트, 짜장면";
		String [] wishListToCharA = wishList.split(",");
		for(int i = 0 ; i <wishListToCharA.length ; i++) {
			System.out.println(wishListToCharA[i]+" ");
		}
		System.out.println();
		
		int num1 = Integer.parseInt("1");
		String numS = String.valueOf(num1);
		numS = Integer.toString(num1);
		
		String cc = Character.toString('g');
		
		printSth(new int[]{1,2,3,10,10,10});
		System.out.println();System.out.println();

		
		int[] twoDemAry[] = new int[3][];
		twoDemAry[0] = new int[3];
		twoDemAry[1] = new int[5];
		twoDemAry[2] = new int[2];
		int n = 1;
		int count = 0;
		for(int i= 0 ; i <twoDemAry.length;i++) {
			for(int j = 0 ; j < twoDemAry[i].length;j++) {
				twoDemAry[i][j]= n++;
				count++;
			}
		}
		
		for(int i= 0 ; i <twoDemAry.length;i++) {
			for(int j = 0 ; j < twoDemAry[i].length;j++) {
				System.out.print(twoDemAry[i][j]+", ");
			}
			System.out.println();
		}
		System.out.println("총 요소 갯수: "+count);
	}
	
	public static void printSth(int[] ary) {
		for(int i = 0 ; i <ary.length;i++) {
			System.out.print(ary[i]+", ");
		}
	}

}
