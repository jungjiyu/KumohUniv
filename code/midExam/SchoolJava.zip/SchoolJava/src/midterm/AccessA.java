package midterm;

import midterm.access.AccessB;

public class AccessA {
	protected AccessA(){
		System.out.println("AccessA객체 생성됨");
		AccessB b = new AccessB() ;
	}
}
