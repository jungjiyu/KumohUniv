package midterm;

public class Person implements Cloneable{
	public int age;
	public String name;
	
	public Person(int age, String name) {
		this.age = age;
		this.name = name;
	}
	
	public Person() {}
	

//	@Override
//	public String toString() {
//		return"( "+age+","+name+" )";
//	}
//	
	@Override
	public boolean equals(Object obj) {
		if(this == obj) {
			System.out.println("객체 자체가 같네요");
			return true;
		}
		if(obj instanceof Person) {
			Person temp = (Person)obj;
			if(this.name == temp.name && this.age == temp.age) return true;
			System.out.println("필드값이 다르네요");
			return false;

		}
		System.out.println("걍 타입이 다르네요");
		return false;
	}
//	
//	@Override
//	public Person clone() {
//		Person p = new Person();
//		p.name = this.name;
//		p.age = this.age;
//		return p;
//	}
	@Override
	public Person clone(){
        Person p =null;
        		try{
        		p=	(Person) super.clone(); 
        		}catch( CloneNotSupportedException e) {}
        return p;
    }
	


	
	

}
