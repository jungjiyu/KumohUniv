package homework3;

import java.util.Scanner;

public class Homework1 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("문자와 정수(1~11) 하나씩 입력:");
		
	// 일단 문자열로 입력 받은후 charAt 을 통해 문자를 추출한다	
		char c = scanner.next().charAt(0);
	// 정수값을 입력받는다	
		int height = scanner.nextInt();
		
	// 범위를 넘어가는 경우 피라미드 출력없이 종료하고, 정상적이면 피라미드를 출력한다
		if(height<0 || height>11) System.out.println("1~11 범위의 수를 입력해주세요.");	
		else print_pyramid(c,height);
		
	// 제대로 입력 받았건 안받았건 scanner 는 반드시 닫아준다	
		scanner.close();
		
	}
	
	// 지정한 문자(ch)를 지정한 수(len)만큼 출력한다
	static void print_chars(char ch , int len) { 
		// 총 len 번 반복한다
		while(len-->0) System.out.print(ch);
	}
	
	static void print_pyramid(char ch, int height) {
		 // 총 height 번 반복한다
		for(int i = 0 ; i <height;i++) {
			// 빈칸을 줄 번호로 채운다
				print_chars(Integer.toString(i).charAt(0),height-(i+1));			
			// ch 를 피라미드의 형태가 되도록 출력한다	
				print_chars(ch,1+2*i);
				print_chars(Integer.toString(i).charAt(0),height-(i+1));			
				System.out.println();
			}
		}
	}



