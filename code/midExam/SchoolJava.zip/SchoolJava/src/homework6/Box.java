package homework6;

public class Box{
private int width, height; // 박스의 너비와 높이
private char fillChar; // 박스를 그리는 데 사용하는 문자
// 매개 변수 없는 생성자, 10x1 의 박스 생성
	public Box() {
		this.width = 10;// this()를 사용하여 완성
		this.height = 1;// this()를 사용하여 완성
	}

// 너비, 높이의 두 매개 변수를 가진 생성자
	public Box(int width, int height) {
			this.width = width;// this 레퍼런스를 사용
			this.height = height;// this 레퍼런스를 사용
	}
	
//박스를 그리는 메소드
	public void draw() {
		for(int i = 0; i < height; i++) {
			for(int j=0;j<width;j++)
				System.out.print(this.fillChar);
			System.out.println();
		}
	}
	// 박스를 그릴 때 사용하는 문자 설정
	public void fill(char s) {
		this.fillChar =s;
	}
	public static void main(String[] args) {
		int $num = 10;
		int 변수 =10;
		System.out.println(변수);
		System.out.println($num);
		Box a = new Box(); // 10x1 사각형
		Box b = new Box(20,3); // 20x3 사각형
		a.fill('*'); // box 를 그릴 때 사용하는 문자는 '*'
		b.fill('%'); // box 를 그릴 때 사용하는 문자는 '%'
		a.draw(); // 박스 a 그리기
		b.draw(); // 박스 b 그리기
	}
	}