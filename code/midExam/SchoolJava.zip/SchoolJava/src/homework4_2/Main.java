package homework4_2;

public class Main {
	public static void main(String[] args) {
		Apple a1 = new Apple("apple1");
		Apple a2 = new Apple("apple2");
		a1.print(a2);
		
	}
}

class Apple{
	private String str;
	public Apple(String str) {
		this.str = str;
	}
	
	public void print(Apple apple){
		System.out.println(this.str);
		System.out.println(apple.str);
	}
}