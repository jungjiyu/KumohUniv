/**
 * 
 */
/**
 * @author windows
 *
 */
module SchoolJava {
}