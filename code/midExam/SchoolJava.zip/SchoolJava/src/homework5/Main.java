package homework5;

import java.util.Scanner;

class Apple{
	int i;
	public Apple(int i) {
		this.i=i;
	}
	
	// 우리가 직접 만드는 클래스에 clone 기능 쓰고 싶으면 직접 오버라이딩해야된다
	public Apple clone() { 
		Apple temp = new Apple(i);
		return temp;
	}
	

	public void print(Apple apple) {
	    System.out.println(this.i);
	    System.out.println(apple.i);

	}


}
public class Main {
	public static void main(String[] args) {
		char[] c1 = "apple".toCharArray();
		char[] c2= c1; // 동일한 캐릭터 배열을 가르키기 떄문에 변경된다
		c2[0] = 'A';
		System.out.println(c1);


		
		c2 = c1.clone(); // 별개의 배열을 가리키게 되어서 변경 사항이 저장되지 않는다
		c2[0] = 'a';
		System.out.println(c1);
		System.out.printf("안녕 %s야","병신");
		String cc =String.valueOf('c');
		System.out.println(cc);
		

		Apple apple1 = new Apple(1);
		Apple apple2 = apple1; // 단순히 같은 객체를 가리킨는거지, 별도의 객체가 생긴게 아니다
		apple2= apple1.clone(); // 새로운 객체를  생성한다
		apple2.i=2;
		// apple1 과 apple2 는 별개의 객체임을 확인할 수 있다.
		apple1.print(apple1);
		apple1.print(apple2);
		apple2.print(apple1);
		apple2.print(apple2);
		
	}
	



	
}
