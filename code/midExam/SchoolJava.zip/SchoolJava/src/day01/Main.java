package day01;

public class Main {
	
	public static int sum(int n, int m) {
		return n + m;
		}
	
	public static int ss;

		
	public static void main(String[] args) {
		double sum_d = 0.0;
		for(int i = 0; i < 1000000; i++) {
		sum_d += 0.1;
		}
		System.out.println("double:" + sum_d);
		
		
		for(int i = 0 ; i<args.length;i++) {
			System.out.println("args["+i+"]= "+ args[i]);
		}
		System.out.println("\n\n");
		
		
		int i = 20;
		int s;
		char a;
		System.out.println(ss);
		s = sum(i, 10); 
		a = '?';
		System.out.println(a); 
		System.out.println("Hello"); 
		System.out.println(s);
		
	}

}
