#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
	int val;
	struct Node* next;
}Node;

void insert(Node**tail , int val) {
	Node* newNode = (Node*)malloc(sizeof(Node));
	newNode->val = val;

	if (*tail == NULL) {
		*tail = newNode;
		newNode->next = newNode;
	}

	else {//�� �� ����
		newNode->next = (*tail)->next;
		(*tail)->next = newNode;
		*tail = newNode;
	}
}

void print(Node* tail) {
	Node* curNode = tail;
	
	do{
		curNode = curNode->next;
		printf("%d ", curNode->val);

	} while (curNode != tail);
}

void delete(Node** tail, int val) {
	if (*tail == NULL) {
		printf("�ش� ����Ʈ�� ��尡 �ϳ��� �����ϴ�\n");
	}

	else if ((*tail)->next == NULL) {
		if ((*tail)->val == val) {
			free(*tail);
			*tail = NULL;
		}
		else {
			printf("�ش� ���� �������� �ʽ��ϴ�\n");

		}
	}


	else {
		Node* delNode, * prevNode;
		delNode = prevNode = *tail;

		while (delNode != NULL) {
			delNode = delNode->next;
			if (delNode->val == val) {
				prevNode->next = delNode->next;
				free(delNode);
				return;
			}
			prevNode = delNode;
		}

		printf("�ش簪�� �������� �ʽ��ϴ�\n");
	}
}


int main(void) {
	Node* tail =NULL;
	insert(&tail, 1);
	insert(&tail, 2);
	insert(&tail, 3);
	insert(&tail, 4);

	print(tail);
	delete(&tail, 1);
	print(tail);
	delete(&tail, 1);
	printf("hehehehe");
	return 0;
}