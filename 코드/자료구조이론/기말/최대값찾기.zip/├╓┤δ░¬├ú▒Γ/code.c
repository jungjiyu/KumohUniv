#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int val;
    struct Node* next; // ���� ��带 ����Ŵ
}Node;

typedef struct List {
    Node* head; // ���� ù ��带 ����Ŵ >> ù ���� ���� �ٸ� ������� ����Ŵ �������ϱ�
    Node* tail; // ���ǻ� ����
}List;

List* NewList() {
    List* new_list = (List*)malloc(sizeof(List));
    new_list->head = NULL;
    return new_list;
}

Node* NewNode(int a) {
    Node* new_node = (Node*)malloc(sizeof(Node));
    new_node->val = a;
    new_node->next = NULL;
    return new_node;

}

void Insert(List* list, int a) {
    Node* new_node = NewNode(a);

    //1. ����ֳ� >> head �� �ʱ�ȭ
    if (list->head == NULL) {
        list->head = new_node;
        list->tail = new_node;
    }

    //2. �� �ڿ� ����
    else {

        Node* current_node = list->tail;
        current_node->next = new_node;
        list->tail = new_node;
    }
}

void PrintList(List* list) {
    Node* current_node = list->head;
    while (current_node != NULL) {
        printf("(%d)   ", current_node->val);
        current_node = current_node->next;
    }
}

int GetMax(List* list) {
    Node* current_node = list->head;
    int max = current_node->val;
    while (current_node != NULL) {
        if (current_node->val > max) {
            max = current_node->val;
        }
        current_node = current_node->next;
    }
    return max;
}


int main() {
    List* list= NewList();
    Insert(list, 1);
    Insert(list, 4);
    Insert(list, 5);
    Insert(list, 2);
    Insert(list, 9);
    PrintList(list);
    int max = GetMax(list);
    printf("\n�ִ밪: %d" , max);

}