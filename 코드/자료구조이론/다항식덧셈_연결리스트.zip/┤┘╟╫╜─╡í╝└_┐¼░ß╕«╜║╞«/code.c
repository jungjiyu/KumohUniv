#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int coef; // ���
    int expon; // ����
    struct Node* next; // ���� ��带 ����Ŵ
}Node;

typedef struct List { 
    Node* head; // ���� ù ��带 ����Ŵ >> ù ���� ���� �ٸ� ������� ����Ŵ �������ϱ�
    Node* tail; // ���ǻ� ����
}List;

List* NewList() {
    List* new_list = (List*)malloc(sizeof(List));
    new_list->head = NULL;
    return new_list;
}

Node* NewNode(int a, int b) {
    Node* new_node = (Node*)malloc(sizeof(Node));
    new_node->coef = a;
    new_node->expon = b;
    new_node->next = NULL;
    return new_node;

}

void Insert(List* list, int a, int b) {
    Node* new_node = NewNode(a,b);

    //1. ����ֳ� >> head �� �ʱ�ȭ
    if (list->head == NULL) {
        list->head = new_node;
        list->tail = new_node;
    }

    //2. �� �ڿ� ����
    else {
       
        Node* current_node = list->tail;
        current_node->next = new_node;
        list->tail = new_node;
    }
}

void PrintList(List* list) {
    Node* current_node = list->head;
    while (current_node != NULL) {
        printf("(%d ,%d)   ", current_node->coef, current_node->expon);
        current_node = current_node->next;
    }
}

List* SumList(List* listA, List* listB) {
    List* listC = NewList();
    Node* current_nodeA = listA->head;
    Node* current_nodeB = listB->head;
    while (current_nodeA != NULL || current_nodeB != NULL) {
        if (current_nodeB == NULL || current_nodeA->expon > current_nodeB->expon) {
            Insert(listC, current_nodeA->coef, current_nodeA->expon);
            current_nodeA = current_nodeA->next;

        }

        else if (current_nodeB == NULL || current_nodeA->expon < current_nodeB->expon) {

            Insert(listC, current_nodeB->coef, current_nodeB->expon);
            current_nodeB = current_nodeB->next;

        }


        else if (current_nodeA->expon == current_nodeB->expon) {
            Insert(listC, current_nodeA->coef + current_nodeB->coef, current_nodeA->expon);
            current_nodeA = current_nodeA->next;
            current_nodeB = current_nodeB->next;

        }
    }

    return listC;
}


int main() {
    List* listA = NewList();
    Insert(listA,3,5);
    Insert(listA,2,3);
    Insert(listA,2,0);
    List* listB = NewList();
    Insert(listB,4,4);
    Insert(listB,5,3);
    Insert(listB,2,1);

    printf("ù ���׽��� (���,����): ");
    PrintList(listA);
    printf("\n");
    printf ("�ι�° ���׽���(���, ����) : ");
    PrintList(listB);
    printf("\n");

    List* listC= SumList(listA, listB);

    printf("������ ���׽���(���, ����) : ");
    PrintList(listC);


    
}