#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MAX 10

int isFULL(int* top) {
	return *top == MAX - 1;
}

int isEmpty(int top) {
	return top==-1;
}

void push(int *stack , int data , int* top) {
	if ( isFULL(top)) {
		printf("-- stack over flow --\n");
		return;
	}

	(*top)++;
	stack[*top] = data;
}

int pop(int *stack , int* top) {
	if (isEmpty(*top)) {
		printf("-- stack under flow --\n");
		return -1;
	}

	int temp = stack[*top];
	(*top)--;
	return temp;
}

void main() {

	srand(time(NULL));
	int stack[MAX];
	int top = -1;

	int data;

	for (int k = 0; k < 5; k++) {
		data = rand() % 20 + 1;
		push(stack,data ,&top);
		printf("Push : %d\n", data);
	}
	printf("\n");
	for (int k = 0; k < 5; k++) {	
		int val = pop(stack, &top);
		if(val!=-1) printf("Pop : %d\n",val ); // push �� �Ͱ� �������� ���´�
	}


}