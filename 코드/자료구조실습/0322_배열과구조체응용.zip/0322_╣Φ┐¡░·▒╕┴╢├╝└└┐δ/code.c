#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
//25�� �����ο���+�߰��ο���(*2�� ��Ÿ)
typedef struct Student
{
    int no;
    char name[20];
    int m;
    int f;
}Stu;

void Insert(Stu* stu_p, int start, int end)
{
    printf("---�Է�---\n");
    for (int k = start; k < end; k++)
    {
        printf("---%d�� �л�___\n", k + 1);
        printf("�й� : ");
        scanf("%d", &stu_p[k].no); //scanf("%d", &(stu_p + k) <- no);
        printf("�̸� : ");
        scanf("%s", &stu_p[k].name);
        printf("�߰� : ");
        scanf("%d", &stu_p[k].m);
        printf("�⸻ : ");
        scanf("%d", &stu_p[k].f);
    }
}

void Sort(Stu* stu_p, int n)
{
    for (int k = n - 1; k > 0; k--)
    {
        for (int w = 0; w < k; w++)
        {
            if ((stu_p[w].m + stu_p[w].f)
                < (stu_p[w + 1].m + stu_p[w + 1].f))
            {
                Stu temp = stu_p[w];
                stu_p[w] = stu_p[w + 1];
                stu_p[w + 1] = temp;
            }
        }
    }
}

void Display(Stu* stu_p, int n)
{
    printf("\n��������\n");
    for (int k = 0; k < n; k++)
    {
        printf("%d�� : %d\n", k + 1, stu_p[k].no);

    }
    printf("----��----\n");
}

void main()
{
    int pre;
    int a;
    printf("�ο� �� �Է�: ");
    scanf("%d", &pre);
    Stu* stu_p = (Stu*)malloc(pre * sizeof(Stu));

    Insert(stu_p, 0, pre);
    Sort(stu_p, pre);
    Display(stu_p, pre);

    int fin;
    printf("�ο� �� �Է�: ");
    scanf("%d", &fin);
    stu_p = (Stu*)realloc(stu_p,(pre+fin) * sizeof(Stu));
    Insert(stu_p, pre, pre+fin);
    Sort(stu_p, pre+fin);
    Display(stu_p, pre+fin);



}