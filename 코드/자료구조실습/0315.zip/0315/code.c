#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


typedef struct{
	int studentID;
	char bookName[100];
	int borrowDate[3];
	int returnDate[3];
} BookInfo;


typedef struct {
	int studentID;
	int grade;
}Student;

void swap(Student* a, Student* b) {
	Student tmp = *a;
	*a = *b;
	*b = tmp;
}

void printBookInfo(BookInfo *A , int size) {
	for (int i = 0; i < size; i++) {
		printf("�й�:%d	", A[i].studentID);
		printf("������:%s	", A[i].bookName);
		printf("������:%d/%d/%d	", A[i].borrowDate[0], A[i].borrowDate[1], A[i].borrowDate[2]);
		printf("�ݳ���:%d/%d/%d	", A[i].returnDate[0], A[i].returnDate[1], A[i].returnDate[2]);

		printf("\n");
	}

}

void selectBookInfo(BookInfo* A, int size) {
	int choice;
	int studentID;
	char bookName[20];

	printf("~~~~~~~~~~~��ȸ ���� ����(1: �й� 2:å �̸�)~~~~~~~~~~~~~~");
	scanf("%d", &choice);

	switch (choice) {
		case 1:
			printf("�й� �Է�:");
			scanf("%d", &studentID);
			selectByID(A, size , studentID);
			break;

		case 2:
			printf("å�̸� �Է�:");
			gets(bookName);
			selectByBookName(A, size, bookName);
			break;


	}
	for (int i = 0; i < size; i++) {
		
		printf("�й�:%d	", A[i].studentID);
		printf("������:%s	", A[i].bookName);
		printf("������:%d/%d/%d	", A[i].borrowDate[0], A[i].borrowDate[1], A[i].borrowDate[2]);
		printf("�ݳ���:%d/%d/%d	", A[i].returnDate[0], A[i].returnDate[1], A[i].returnDate[2]);

		printf("\n");
	}

}

void selectByID(BookInfo* A, int size, int id) {
	for (int i = 0; i < size; i++) {
		if (id == A[i].studentID) {
			printf("-------------------------------------------------------------------------------");
			printf("�й�:%d	", A[i].studentID);
			printf("������:%s	", A[i].bookName);
			printf("������:%d/%d/%d	", A[i].borrowDate[0], A[i].borrowDate[1], A[i].borrowDate[2]);
			printf("�ݳ���:%d/%d/%d	", A[i].returnDate[0], A[i].returnDate[1], A[i].returnDate[2]);
			printf("-------------------------------------------------------------------------------");
			break;
		}
	}

	printf("�й��� ��ġ�ϴ� �뿩�ڰ� �������� �ʽ��ϴ�\n");

}


void selectByBookName(BookInfo* A, int size, int id) {
	for (int i = 0; i < size; i++) {
		if (id == A[i].studentID) {
			printf("-------------------------------------------------------------------------------");
			printf("�й�:%d	", A[i].studentID);
			printf("������:%s	", A[i].bookName);
			printf("������:%d/%d/%d	", A[i].borrowDate[0], A[i].borrowDate[1], A[i].borrowDate[2]);
			printf("�ݳ���:%d/%d/%d	", A[i].returnDate[0], A[i].returnDate[1], A[i].returnDate[2]);
			printf("-------------------------------------------------------------------------------");
			break;
		}
	}

	printf("�й��� ��ġ�ϴ� �뿩�ڰ� �������� �ʽ��ϴ�\n");

}



void insertBookInfo(BookInfo* A, int size) {
	for (int i = 0; i < size; i++) {
		printf("�й�: ");
		scanf("%d", &(A[i].studentID));
		getchar();
		printf("������: ");
		gets(A[i].bookName);

		printf("������: ");
		scanf("%d/%d/%d", &(A[i].borrowDate[0]), &(A[i].borrowDate[1]), &(A[i].borrowDate[2]));
		getchar();
		A[i].returnDate[0] = A[i].borrowDate[0];
		int month = A[i].returnDate[1] = A[i].borrowDate[1];
		A[i].returnDate[2] = A[i].borrowDate[2] + 10;

		if (month == 2) { // 28��
			if (A[i].returnDate[2] - 28 > 0) {
				A[i].returnDate[1] += 1;
				A[i].returnDate[2] -= 28;
			}
		}
		else if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) { // 31��
			if (A[i].returnDate[2] - 31 > 0) {
				A[i].returnDate[1] += 1;
				A[i].returnDate[2] -= 31;
			}

			if (A[i].returnDate[1] > 12) {
				A[i].returnDate[1] = 1;
				A[i].returnDate[0] += 1;

			}
		}
		else { //30 ��

			if (A[i].returnDate[2] - 30 > 0) {
				A[i].returnDate[1] += 1;
				A[i].returnDate[2] -= 30;
			}

		}

		printf("\n");
	}


}


int main(void) {

	Student s1 = { 20231073, 100 };
	Student s2 = { 20241073, 10 };
	printf("s1: %d ,%d\n", s1.grade, s1.studentID);
	printf("s2: %d , %d\n", s2.grade, s2.studentID);
	printf("\n--------------------------\n");
	swap(&s1, &s2);
	printf("s1: %d , %d\n",s1.grade , s1.studentID);
	printf("s2: %d , %d\n",s2.grade , s2.studentID);


	printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

	

	BookInfo A[20] = { {20231111, "book1",{2023,12,23},{2024,1,2}} ,{20232222, "book2",{2020,10,11},{2020,10,21}} ,{20233333, "book3",{2020,11,11},{2020,11,21}} };
	int count = 3;

	printBookInfo(A, count);
	printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~���� �Է� �޾� ����~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	insertBookInfo(A,3);
	printBookInfo(A, 3);

	while (1) {
		int choice;
		printf("~~~~~~~1. �űԴ뿩 2. ��ȸ 3. ���� ~~~~~~~");
		scanf("%d", &choice);
		switch (choice) {
			
			case 1:
				if (count < 20) {
					insertBookInfo(A, 1);
					count++;
				}
				else { printf("�����ڰ� �ʹ� �����ϴ�\n"); }
				break;

			case 2:
				printBookInfo(A, count);
				break;

			case 3:
				selectBookInfo(A, count);

		}
	}

	return 0;

}
