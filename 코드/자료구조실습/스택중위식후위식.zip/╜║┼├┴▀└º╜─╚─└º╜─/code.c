#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 100

typedef int element;
element Stack[MAX];
int top = -1;

void push(element data) {
	if (top == MAX-1) {
		printf("����\n");
		return;
	}

	Stack[++top] = data;

}

int pop() {
	if (top == -1) {
		return -1;
	}
	return Stack[top--];
}

int e(int c) {
	switch (c) {
	case '*':
	case '/':
		return 2;
	case '+':
	case '-':
		return 1;
	default: // ������ ����
		return 0;
	}
}

int r_paren(char* postfix, int* p_index) {
	char temp;
	while (1) {
		temp = pop();
		if (temp == '(') {
			return;
		}
		else {
			postfix[(*p_index)++] = temp;
		}
	}
}

void operator(char* postfix, int* p_index, int temp) {
	if (e(temp) <= e(Stack[top])) { // ���ų� ���� ���� �ִ���
		postfix[*p_index] = pop();
	}

	if (e(temp) <= e(Stack[top])) {  //���� ���� �ִ���? (��·�� 2��)
		postfix[*p_index] = pop();
	}
	push(temp);
}

void infixToPostfix(char* infix, char* postfix) {
	int len = strlen(infix); // �������� �� ����
	int p_index = 0;
	char temp;

	for (int k = 0; k < len; k++) {
		temp = infix[k];

		switch (temp) {
		case '(':
			push(temp);
			break;

		case ')':
			r_paren(postfix, &p_index);
			break;

		case '+':
		case '-':
		case '*':
		case '/':
			operator(postfix, &p_index, temp);
			break;
		default:
			postfix[p_index++] = temp;
			break;
		}

		while (top != -1) {
			postfix[p_index++] = pop();
		}

		postfix[p_index] = '\0';

	}

}

void main() {
	char infix[MAX], postfix[MAX];
	while (1) {
		printf("������ �Է�:");
		scanf("%s", infix);

		infixToPostfix(infix,postfix);
		printf("������:");
		printf("%s", postfix);
		printf("\n");
	}



}