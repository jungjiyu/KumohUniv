#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct node {
	int val;
	struct node* prev;
	struct node* next;
}Node;

typedef struct List {
	Node* head;
	int count;
}List;

List* createList() {
	List* newList = (List*)malloc(sizeof(List));
	newList->head = NULL;
	newList->count = 0;
	return newList;
}

Node* createNode(int val) {
	Node* newNode = (Node*)malloc(sizeof(Node));
	newNode->val = val;
	newNode->next= NULL;
	return newNode;
}

void insert(List* list, int val, int k) {
	Node* newNode = createNode(val);

	if (list->head == NULL) { // �ƹ��͵� ���»���
		list->head = newNode;
	}

	if (k == 0) {
		newNode->next = list->head;
		list->head->next = newNode;
		list->head = newNode;
	}
	else {// �߰�
		int num = k;

		//k�� �̵�
		Node* curNode = list->head; // 0��° ��� 
		while (--num) { // k-1�� �̵�
			curNode = curNode->next;
		}
	

		// while �� ���� �� curNode == k-1���� ���
		newNode->next = curNode->next;
		curNode->next = newNode;

	}
	list->count++;

}




void printList(List* list) {
	Node* curNode = list->head;
	if (curNode == NULL) {
		printf("����� ��尡 �����ϴ�");
	}
	/*
	while (curNode != NULL) {
		printf("%d ", curNode->val);
		curNode = curNode->next;
	}
	printf("\n");
	*/

	curNode = list->head;
	for (int i = 1; i <= 100; i++) {
		printf("%d ", curNode->val);
		curNode = curNode->next;
	}
	printf("\n");


	printf("\n");

}

void delete(List* list, int k) {
	if (k >= list->count) {
		printf("���� �Ұ��� �ε���\n");
		return;
	}

	if (list->head == NULL) {
		printf("�ش� ����Ʈ�� ��尡 �ϳ��� �����ϴ�\n");
		return;
	}

	else if (k == 0) { // ó��
		Node* delNode = list->head;

		Node* curNode = list->head;
		while (curNode->next != delNode) { // ������ ������
			curNode = curNode->next;
		}
		curNode->next = delNode ->next;
		list->head = list->head->next;

		free(delNode);
	}



	else { //�߰� Ȥ�� ������
		Node* curNode = list->head;
		int n = k;
		while (--n) {
			curNode = curNode->next;
		}
		Node* delNode = curNode->next;
		curNode->next = curNode->next->next;
		free(delNode);


	}
	(list->count)--;
}



int main() {

	List* list = createList();
	insert(list, 1, 0);
	insert(list, 2, 1);
	insert(list, 3, 2);
	insert(list, 4, 3);
	insert(list, 5, 4);
	insert(list, 6, 3);

	printList(list);

	delete(list, 0);
	printList(list);



}