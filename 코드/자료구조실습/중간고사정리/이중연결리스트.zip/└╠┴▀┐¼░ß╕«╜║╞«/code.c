#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
	int data;
	struct Node* next;
	struct Node* prev;
}Node;

typedef struct List {
	Node* head;
}List;

Node* New(int data) {
	Node* newNode = (Node*)malloc(sizeof(Node));
	newNode->prev = newNode->next = NULL;
	newNode->data = data;
	return newNode;
}

void insert(List* list, int val, int k) {
	Node* newNode = New(val);

	if (list->head == NULL) { // �ƹ��͵� ���»���
		list->head = newNode;
	}

	if (k == 0) {
		newNode->next = list->head;
		list->head->prev = newNode;
		list->head = newNode;
	}
	else {// �߰�
		int num = k;

		//k�� �̵�
		Node* curNode = list->head; // 0��° ��� 
		while (--num) { // k-1�� �̵�
			curNode = curNode->next;
		}


		// while �� ���� �� curNode == k-1���� ���
		if (curNode->next != NULL) {
			curNode->next->prev = newNode;
			newNode->next = curNode->next;

			curNode->next = newNode;
			newNode->prev = curNode;
		}

		else {
			curNode->next = newNode;
			newNode->prev = curNode;
			newNode->next = NULL;

		}

	}

}


void display(Node* cur) {
	printf("\n������\n");
	while (cur->next != NULL) {
		printf("%d -> ", cur->data);
		cur = cur->next;

	}
	printf("%d \n", cur->data);
	printf("\n����\n");

	while (cur->prev != NULL) {
		printf("%d -> ", cur->data);
		cur = cur->prev;

	}
	printf("%d \n", cur->data);



}
void delete(List* list, int k) {
	if (list->head == NULL) {
		printf("�ش� ����Ʈ�� ��尡 �ϳ��� �����ϴ�\n");
	}



	else {
		Node* curNode = list->head; // 0��° ��� 

		int num = k;
		while (--num) { // k-1�� �̵�

			curNode = curNode->next;
		}
		Node* delNode = curNode->next;
		curNode->next->next->prev = curNode;
		curNode->next = curNode->next->next;
		free(delNode);


	}
}


int main(void) {
	List list;
	list.head = NULL;
	Node* temp;

	temp = New(5);
	list.head = temp;

	for (int k = 4; k > 0; k--) {
		temp = New(k);
		temp->next = list.head;
		list.head->prev = temp;
		list.head = temp;
	}

	display(list.head);
	insert(&list, 6, 3); // 3�� ��� �ڿ� 6�� ��� �߰�
	display(list.head);

	delete(&list, 2); // 3�� ��� ����
	display(list.head);



	return 0;
}